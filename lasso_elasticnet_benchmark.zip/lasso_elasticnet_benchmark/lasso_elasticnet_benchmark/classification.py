from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import pandas as pd
from bayes_opt import BayesianOptimization
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
)
from sklearn.model_selection import StratifiedKFold, cross_val_score
from xgboost import XGBClassifier

from common import save_json, stratified_bootstrap_ci


def rf_model(parameters, n_jobs, seed):
    return RandomForestClassifier(
        n_estimators=int(round(parameters["n_estimators"])),
        max_depth=int(round(parameters["max_depth"])),
        min_samples_split=int(round(parameters["min_samples_split"])),
        min_samples_leaf=int(round(parameters["min_samples_leaf"])),
        max_features=float(parameters["max_features"]),
        bootstrap=bool(int(round(parameters["bootstrap"]))),
        criterion=(
            "gini" if parameters["criterion"] < 0.5 else "entropy"
        ),
        class_weight="balanced_subsample",
        n_jobs=n_jobs,
        random_state=seed,
    )


def xgb_model(parameters, n_classes, n_jobs, seed):
    return XGBClassifier(
        objective="multi:softprob",
        num_class=n_classes,
        eval_metric="mlogloss",
        tree_method="hist",
        n_estimators=int(round(parameters["n_estimators"])),
        max_depth=int(round(parameters["max_depth"])),
        learning_rate=float(
            10 ** parameters["log10_learning_rate"]
        ),
        subsample=float(parameters["subsample"]),
        colsample_bytree=float(parameters["colsample_bytree"]),
        min_child_weight=float(parameters["min_child_weight"]),
        gamma=float(parameters["gamma"]),
        reg_alpha=float(10 ** parameters["log10_reg_alpha"]),
        reg_lambda=float(10 ** parameters["log10_reg_lambda"]),
        n_jobs=n_jobs,
        random_state=seed,
    )


def optimize_classifier(
    name,
    X_train,
    y_train,
    cv_folds,
    scoring,
    init_points,
    n_iter,
    n_jobs,
    random_state,
    output_dir: Path,
):
    output_dir.mkdir(parents=True, exist_ok=True)

    cv = StratifiedKFold(
        n_splits=cv_folds,
        shuffle=True,
        random_state=random_state,
    )

    n_classes = len(np.unique(y_train))
    log = []

    def save_partial_log():
        pd.DataFrame(log).to_csv(
            output_dir / f"{name}_bayes_optimization_log_partial.csv",
            index=False,
        )

    def rf_objective(
        n_estimators,
        max_depth,
        min_samples_split,
        min_samples_leaf,
        max_features,
        bootstrap,
        criterion,
    ):
        parameters = {
            "n_estimators": n_estimators,
            "max_depth": max_depth,
            "min_samples_split": min_samples_split,
            "min_samples_leaf": min_samples_leaf,
            "max_features": max_features,
            "bootstrap": bootstrap,
            "criterion": criterion,
        }
        model = rf_model(parameters, n_jobs, random_state)

        start = time.perf_counter()
        scores = cross_val_score(
            model,
            X_train,
            y_train,
            cv=cv,
            scoring=scoring,
            n_jobs=1,
        )
        elapsed = time.perf_counter() - start

        record = {
            **{key: float(value) for key, value in parameters.items()},
            "mean_cv_score": float(np.mean(scores)),
            "sd_cv_score": float(np.std(scores, ddof=1)),
            "evaluation_seconds": float(elapsed),
        }
        log.append(record)
        save_partial_log()

        print(
            f"{name.upper()} BO evaluation {len(log)}: "
            f"score={record['mean_cv_score']:.6f}, "
            f"time={elapsed / 60:.2f} min",
            flush=True,
        )

        return record["mean_cv_score"]

    def xgb_objective(
        n_estimators,
        max_depth,
        log10_learning_rate,
        subsample,
        colsample_bytree,
        min_child_weight,
        gamma,
        log10_reg_alpha,
        log10_reg_lambda,
    ):
        parameters = {
            "n_estimators": n_estimators,
            "max_depth": max_depth,
            "log10_learning_rate": log10_learning_rate,
            "subsample": subsample,
            "colsample_bytree": colsample_bytree,
            "min_child_weight": min_child_weight,
            "gamma": gamma,
            "log10_reg_alpha": log10_reg_alpha,
            "log10_reg_lambda": log10_reg_lambda,
        }
        model = xgb_model(
            parameters,
            n_classes,
            n_jobs,
            random_state,
        )

        start = time.perf_counter()
        scores = cross_val_score(
            model,
            X_train,
            y_train,
            cv=cv,
            scoring=scoring,
            n_jobs=1,
        )
        elapsed = time.perf_counter() - start

        record = {
            **{key: float(value) for key, value in parameters.items()},
            "mean_cv_score": float(np.mean(scores)),
            "sd_cv_score": float(np.std(scores, ddof=1)),
            "evaluation_seconds": float(elapsed),
        }
        log.append(record)
        save_partial_log()

        print(
            f"{name.upper()} BO evaluation {len(log)}: "
            f"score={record['mean_cv_score']:.6f}, "
            f"time={elapsed / 60:.2f} min",
            flush=True,
        )

        return record["mean_cv_score"]

    if name == "rf":
        objective = rf_objective
        bounds = {
            "n_estimators": (100, 500),
            "max_depth": (4, 20),
            "min_samples_split": (2, 15),
            "min_samples_leaf": (1, 8),
            "max_features": (0.05, 0.5),
            "bootstrap": (0, 1),
            "criterion": (0, 1),
        }
    elif name == "xgb":
        objective = xgb_objective
        bounds = {
            "n_estimators": (100, 500),
            "max_depth": (3, 10),
            "log10_learning_rate": (-3, -0.3),
            "subsample": (0.6, 1.0),
            "colsample_bytree": (0.1, 0.8),
            "min_child_weight": (1, 10),
            "gamma": (0, 5),
            "log10_reg_alpha": (-4, 1),
            "log10_reg_lambda": (-3, 2),
        }
    else:
        raise ValueError("name must be 'rf' or 'xgb'")

    optimizer = BayesianOptimization(
        f=objective,
        pbounds=bounds,
        random_state=random_state,
        verbose=2,
        allow_duplicate_points=True,
    )

    start = time.perf_counter()
    optimizer.maximize(
        init_points=init_points,
        n_iter=n_iter,
    )
    elapsed = time.perf_counter() - start

    best = {
        key: float(value)
        for key, value in optimizer.max["params"].items()
    }
    best["best_cv_score"] = float(optimizer.max["target"])

    pd.DataFrame(log).sort_values(
        "mean_cv_score",
        ascending=False,
    ).to_csv(
        output_dir / f"{name}_bayes_optimization_log.csv",
        index=False,
    )

    save_json(
        best,
        output_dir / f"{name}_best_params.json",
    )

    return best, elapsed


def fit_evaluate(
    name,
    best,
    X_train,
    y_train,
    X_test,
    y_test,
    class_names,
    n_jobs,
    bootstrap_repetitions,
    confidence_level,
    random_state,
    output_dir: Path,
):
    output_dir.mkdir(parents=True, exist_ok=True)
    n_classes = len(class_names)

    model = (
        rf_model(best, n_jobs, random_state)
        if name == "rf"
        else xgb_model(best, n_classes, n_jobs, random_state)
    )

    start = time.perf_counter()
    model.fit(X_train, y_train)
    fit_seconds = time.perf_counter() - start

    start = time.perf_counter()
    predictions = model.predict(X_test)
    prediction_seconds = time.perf_counter() - start

    metrics = {
        "classifier": name,
        "accuracy": float(accuracy_score(y_test, predictions)),
        "weighted_f1": float(
            f1_score(
                y_test,
                predictions,
                average="weighted",
                zero_division=0,
            )
        ),
        "model_fit_seconds": float(fit_seconds),
        "prediction_seconds": float(prediction_seconds),
        "n_features": int(X_train.shape[1]),
    }

    metrics.update(
        stratified_bootstrap_ci(
            y_test,
            predictions,
            bootstrap_repetitions,
            confidence_level,
            random_state,
        )
    )

    pd.DataFrame(
        classification_report(
            y_test,
            predictions,
            target_names=class_names,
            output_dict=True,
            zero_division=0,
        )
    ).T.to_csv(
        output_dir / f"{name}_classification_report.csv"
    )

    pd.DataFrame(
        confusion_matrix(y_test, predictions),
        index=class_names,
        columns=class_names,
    ).to_csv(
        output_dir / f"{name}_confusion_matrix.csv"
    )

    pd.DataFrame(
        {
            "y_true_encoded": y_test,
            "y_pred_encoded": predictions,
            "y_true": [class_names[i] for i in y_test],
            "y_pred": [class_names[i] for i in predictions],
        }
    ).to_csv(
        output_dir / f"{name}_test_predictions.csv",
        index=False,
    )

    save_json(
        metrics,
        output_dir / f"{name}_test_metrics.json",
    )

    return metrics
