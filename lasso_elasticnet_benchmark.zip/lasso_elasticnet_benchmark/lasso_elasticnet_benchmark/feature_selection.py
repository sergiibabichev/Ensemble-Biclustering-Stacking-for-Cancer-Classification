from __future__ import annotations

import time
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.exceptions import ConvergenceWarning
from sklearn.feature_selection import f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

from common import save_json


def build_model(
    method: str,
    C: float,
    elasticnet_l1_ratio: float,
    max_iter: int,
    tol: float,
    random_state: int,
) -> LogisticRegression:
    """
    Build multinomial regularized logistic regression for scikit-learn 1.8+.

    In scikit-learn 1.8, l1_ratio determines the regularization:
      l1_ratio = 1.0 -> L1 (LASSO)
      0 < l1_ratio < 1 -> Elastic Net
    """
    if method == "lasso":
        l1_ratio = 1.0
    elif method == "elasticnet":
        l1_ratio = float(elasticnet_l1_ratio)
        if not 0.0 < l1_ratio < 1.0:
            raise ValueError(
                "For Elastic Net, elasticnet_l1_ratio must be between 0 and 1."
            )
    else:
        raise ValueError("method must be 'lasso' or 'elasticnet'")

    return LogisticRegression(
        C=float(C),
        l1_ratio=l1_ratio,
        solver="saga",
        max_iter=int(max_iter),
        tol=float(tol),
        random_state=int(random_state),
    )


def fit_rank_and_select(
    method,
    X_train,
    y_train,
    top_k,
    lasso_c,
    elasticnet_c,
    elasticnet_l1_ratio,
    max_iter,
    tol,
    coefficient_zero_tol,
    random_state,
    output_dir: Path,
):
    """
    Fit LASSO/Elastic Net once with fixed parameters, rank genes, and select top-k.

    A gene is considered nonzero when at least one class-specific coefficient has
    absolute value greater than coefficient_zero_tol.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    total_start = time.perf_counter()

    n_input_genes = int(X_train.shape[1])
    selected_count = min(int(top_k), n_input_genes)

    # 1. Training-only standardization.
    start = time.perf_counter()
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_train).astype(np.float32, copy=False)
    scaling_seconds = time.perf_counter() - start

    # 2. One fixed regularized logistic-regression fit.
    C = float(lasso_c if method == "lasso" else elasticnet_c)
    l1_ratio = 1.0 if method == "lasso" else float(elasticnet_l1_ratio)

    model = build_model(
        method=method,
        C=C,
        elasticnet_l1_ratio=elasticnet_l1_ratio,
        max_iter=max_iter,
        tol=tol,
        random_state=random_state,
    )

    start = time.perf_counter()
    convergence_warning_raised = False

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always", ConvergenceWarning)
        model.fit(X_scaled, y_train)
        convergence_warning_raised = any(
            issubclass(item.category, ConvergenceWarning) for item in caught
        )

    fitting_seconds = time.perf_counter() - start

    # 3. Coefficient-based gene statistics.
    start = time.perf_counter()

    coefficients = np.asarray(model.coef_, dtype=np.float64)
    abs_coefficients = np.abs(coefficients)

    mean_abs = np.mean(abs_coefficients, axis=0)
    max_abs = np.max(abs_coefficients, axis=0)

    nonzero_class_count = np.sum(
        abs_coefficients > float(coefficient_zero_tol),
        axis=0,
    )

    is_nonzero_gene = nonzero_class_count > 0
    total_nonzero_genes = int(np.sum(is_nonzero_gene))
    total_zero_genes = int(n_input_genes - total_nonzero_genes)

    # Training-only ANOVA is used only to order coefficient ties.
    f_scores, p_values = f_classif(X_scaled, y_train)
    f_scores = np.nan_to_num(
        f_scores,
        nan=-np.inf,
        posinf=np.finfo(float).max,
        neginf=-np.inf,
    )
    p_values = np.nan_to_num(
        p_values,
        nan=1.0,
        posinf=1.0,
        neginf=1.0,
    )

    ranking = pd.DataFrame(
        {
            "gene": X_train.columns.astype(str),
            "mean_abs_coefficient": mean_abs,
            "max_abs_coefficient": max_abs,
            "nonzero_class_count": nonzero_class_count,
            "is_nonzero_gene": is_nonzero_gene,
            "anova_f_score_tiebreaker": f_scores,
            "anova_p_value": p_values,
        }
    )

    ranking = ranking.sort_values(
        by=[
            "is_nonzero_gene",
            "mean_abs_coefficient",
            "max_abs_coefficient",
            "anova_f_score_tiebreaker",
            "gene",
        ],
        ascending=[False, False, False, False, True],
        kind="mergesort",
    ).reset_index(drop=True)

    ranking["rank"] = np.arange(1, len(ranking) + 1)
    ranking["selected_top_k"] = ranking["rank"] <= selected_count

    selected_genes = ranking.loc[
        ranking["selected_top_k"], "gene"
    ].tolist()

    selected_nonzero_genes = int(
        ranking.loc[ranking["selected_top_k"], "is_nonzero_gene"].sum()
    )
    selected_zero_genes = int(selected_count - selected_nonzero_genes)

    ranking_seconds = time.perf_counter() - start

    # 4. Save detailed outputs.
    ranking_path = output_dir / f"{method}_gene_ranking.csv"
    selected_path = output_dir / f"{method}_selected_genes_top_{selected_count}.csv"

    ranking.to_csv(ranking_path, index=False)

    ranking.loc[
        ranking["selected_top_k"],
        [
            "gene",
            "rank",
            "mean_abs_coefficient",
            "max_abs_coefficient",
            "nonzero_class_count",
            "is_nonzero_gene",
            "anova_f_score_tiebreaker",
            "anova_p_value",
        ],
    ].to_csv(selected_path, index=False)

    parameters = {
        "method": method,
        "C": C,
        "l1_ratio": l1_ratio,
        "solver": "saga",
        "max_iter": int(max_iter),
        "tol": float(tol),
        "coefficient_zero_tolerance": float(coefficient_zero_tol),
        "random_state": int(random_state),
        "standardization": "StandardScaler fitted on training data only",
    }

    nonzero_summary = {
        "method": method,
        "number_of_input_genes": n_input_genes,
        "total_number_of_nonzero_genes": total_nonzero_genes,
        "total_number_of_zero_genes": total_zero_genes,
        "nonzero_gene_fraction": (
            float(total_nonzero_genes / n_input_genes)
            if n_input_genes else 0.0
        ),
        "requested_top_k": int(top_k),
        "actual_selected_gene_count": selected_count,
        "selected_nonzero_genes": selected_nonzero_genes,
        "selected_zero_genes": selected_zero_genes,
        "all_nonzero_genes_included_in_top_k": bool(
            selected_nonzero_genes == total_nonzero_genes
            if total_nonzero_genes <= selected_count
            else selected_nonzero_genes == selected_count
        ),
        "coefficient_zero_tolerance": float(coefficient_zero_tol),
        "convergence_warning_raised": convergence_warning_raised,
        "n_iter_per_class": np.asarray(model.n_iter_).astype(int).tolist(),
        "maximum_n_iter_used": int(np.max(model.n_iter_)),
    }

    runtime = {
        "feature_scaling_seconds": float(scaling_seconds),
        "feature_model_fit_seconds": float(fitting_seconds),
        "gene_ranking_seconds": float(ranking_seconds),
        "feature_selection_total_seconds": float(
            time.perf_counter() - total_start
        ),
        **nonzero_summary,
    }

    save_json(
        parameters,
        output_dir / f"{method}_feature_parameters.json",
    )
    save_json(
        nonzero_summary,
        output_dir / f"{method}_nonzero_gene_summary.json",
    )
    save_json(
        runtime,
        output_dir / f"{method}_feature_runtime.json",
    )

    # 5. Immediate console report.
    print("\n" + "=" * 72, flush=True)
    print(f"FEATURE SELECTION: {method.upper()}", flush=True)
    print(f"Input genes:                {n_input_genes}", flush=True)
    print(f"Total nonzero genes:        {total_nonzero_genes}", flush=True)
    print(f"Total zero genes:           {total_zero_genes}", flush=True)
    print(f"Selected genes:             {selected_count}", flush=True)
    print(f"Selected nonzero genes:     {selected_nonzero_genes}", flush=True)
    print(f"Selected zero genes:        {selected_zero_genes}", flush=True)
    print(f"Model fit time, seconds:    {fitting_seconds:.2f}", flush=True)
    print(f"Convergence warning:        {convergence_warning_raised}", flush=True)
    print("=" * 72 + "\n", flush=True)

    return selected_genes, runtime
