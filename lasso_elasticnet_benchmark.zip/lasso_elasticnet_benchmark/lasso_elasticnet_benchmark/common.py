from __future__ import annotations

import json
import os
import platform
import random
import sys
from pathlib import Path
from typing import Any, Dict, Tuple

import numpy as np
import pandas as pd
import psutil
import sklearn
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder


def set_reproducibility(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)


def load_dataset(csv_path: Path, class_column: str) -> Tuple[pd.DataFrame, pd.Series]:
    data = pd.read_csv(csv_path, low_memory=False)

    if class_column not in data.columns:
        raise ValueError(f"Class column '{class_column}' was not found.")

    y = data[class_column].astype(str).copy()
    X = data.drop(columns=[class_column])

    X.columns = X.columns.astype(str).str.replace(r"^X", "", regex=True)
    X = X.apply(pd.to_numeric, errors="raise").astype(np.float32)

    if X.columns.duplicated().any():
        duplicated = X.columns[X.columns.duplicated()].tolist()
        raise ValueError(
            "Duplicated gene names were found after cleaning. "
            f"Examples: {duplicated[:10]}"
        )

    return X, y


def create_fixed_split(X, y_text, test_size, random_state):
    encoder = LabelEncoder()
    y = encoder.fit_transform(y_text)

    idx = np.arange(len(y))
    train_idx, test_idx = train_test_split(
        idx,
        test_size=test_size,
        random_state=random_state,
        stratify=y,
    )

    split = pd.DataFrame(
        {
            "row_index": idx,
            "subset": np.where(np.isin(idx, train_idx), "train", "test"),
            "class_original": y_text.to_numpy(),
            "class_encoded": y,
        }
    )

    return (
        X.iloc[train_idx].copy(),
        X.iloc[test_idx].copy(),
        y[train_idx],
        y[test_idx],
        encoder,
        split,
    )


def stratified_bootstrap_ci(
    y_true,
    y_pred,
    repetitions,
    confidence_level,
    random_state,
):
    rng = np.random.default_rng(random_state)
    groups = {c: np.flatnonzero(y_true == c) for c in np.unique(y_true)}

    acc = np.empty(repetitions)
    wf1 = np.empty(repetitions)

    for b in range(repetitions):
        sample = np.concatenate(
            [rng.choice(indices, len(indices), replace=True)
             for indices in groups.values()]
        )
        acc[b] = accuracy_score(y_true[sample], y_pred[sample])
        wf1[b] = f1_score(
            y_true[sample],
            y_pred[sample],
            average="weighted",
            zero_division=0,
        )

    alpha = 1.0 - confidence_level
    lo = 100.0 * alpha / 2.0
    hi = 100.0 * (1.0 - alpha / 2.0)

    return {
        "accuracy_ci_lower": float(np.percentile(acc, lo)),
        "accuracy_ci_upper": float(np.percentile(acc, hi)),
        "weighted_f1_ci_lower": float(np.percentile(wf1, lo)),
        "weighted_f1_ci_upper": float(np.percentile(wf1, hi)),
        "bootstrap_repetitions": int(repetitions),
        "confidence_level": float(confidence_level),
    }


def save_json(data: Dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    def convert(obj):
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, Path):
            return str(obj)
        raise TypeError(type(obj))

    path.write_text(
        json.dumps(data, indent=2, ensure_ascii=False, default=convert),
        encoding="utf-8",
    )


def collect_environment_info(n_jobs: int) -> Dict[str, Any]:
    info = {
        "platform": platform.platform(),
        "python_version": sys.version,
        "logical_cpu_count": psutil.cpu_count(logical=True),
        "physical_cpu_count": psutil.cpu_count(logical=False),
        "ram_gb": psutil.virtual_memory().total / 1024**3,
        "configured_n_jobs": n_jobs,
        "numpy_version": np.__version__,
        "pandas_version": pd.__version__,
        "scikit_learn_version": sklearn.__version__,
    }

    try:
        import xgboost
        info["xgboost_version"] = xgboost.__version__
    except Exception as exc:
        info["xgboost_version"] = str(exc)

    try:
        import bayes_opt
        info["bayesian_optimization_version"] = getattr(
            bayes_opt, "__version__", "unknown"
        )
    except Exception as exc:
        info["bayesian_optimization_version"] = str(exc)

    return info


def save_selected_matrices(
    X_train,
    X_test,
    y_train_text,
    y_test_text,
    selected_genes,
    output_dir: Path,
    prefix: str,
):
    output_dir.mkdir(parents=True, exist_ok=True)

    train_data = X_train.loc[:, selected_genes].copy()
    test_data = X_test.loc[:, selected_genes].copy()

    train_data["Class"] = list(y_train_text)
    test_data["Class"] = list(y_test_text)

    try:
        train_path = output_dir / f"{prefix}_train.parquet"
        test_path = output_dir / f"{prefix}_test.parquet"
        train_data.to_parquet(train_path, index=False)
        test_data.to_parquet(test_path, index=False)
    except Exception:
        train_path = output_dir / f"{prefix}_train.csv.gz"
        test_path = output_dir / f"{prefix}_test.csv.gz"
        train_data.to_csv(train_path, index=False, compression="gzip")
        test_data.to_csv(test_path, index=False, compression="gzip")

    return {
        "train_matrix": str(train_path),
        "test_matrix": str(test_path),
    }
