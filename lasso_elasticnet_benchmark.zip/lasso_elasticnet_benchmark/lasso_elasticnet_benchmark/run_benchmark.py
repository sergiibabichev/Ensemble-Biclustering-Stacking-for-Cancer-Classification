from __future__ import annotations

import argparse
import time

import pandas as pd

import config
from classification import fit_evaluate, optimize_classifier
from common import (
    collect_environment_info,
    create_fixed_split,
    load_dataset,
    save_json,
    save_selected_matrices,
    set_reproducibility,
)
from feature_selection import fit_rank_and_select


def parse_arguments():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--methods",
        nargs="+",
        choices=["lasso", "elasticnet"],
        default=list(config.FEATURE_METHODS),
    )

    parser.add_argument(
        "--classifiers",
        nargs="+",
        choices=["rf", "xgb"],
        default=list(config.CLASSIFIERS),
    )

    return parser.parse_args()


def main():
    args = parse_arguments()

    set_reproducibility(config.RANDOM_STATE)
    config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    save_json(
        collect_environment_info(config.N_JOBS),
        config.OUTPUT_DIR / "environment.json",
    )

    X, y_text = load_dataset(
        config.INPUT_FILE,
        config.CLASS_COLUMN,
    )

    X_train, X_test, y_train, y_test, encoder, split = (
        create_fixed_split(
            X,
            y_text,
            config.TEST_SIZE,
            config.RANDOM_STATE,
        )
    )

    split.to_csv(
        config.OUTPUT_DIR / "fixed_train_test_split.csv",
        index=False,
    )

    save_json(
        {
            "classes": encoder.classes_.tolist(),
            "n_total": int(len(y_text)),
            "n_train": int(len(y_train)),
            "n_test": int(len(y_test)),
            "n_input_genes": int(X.shape[1]),
            "test_size": float(config.TEST_SIZE),
            "random_state": int(config.RANDOM_STATE),
        },
        config.OUTPUT_DIR / "split_metadata.json",
    )

    y_train_text = encoder.inverse_transform(y_train)
    y_test_text = encoder.inverse_transform(y_test)

    result_rows = []
    feature_summary_rows = []

    for method in args.methods:
        method_dir = config.OUTPUT_DIR / method
        method_dir.mkdir(parents=True, exist_ok=True)
        method_start = time.perf_counter()

        genes, feature_runtime = fit_rank_and_select(
            method=method,
            X_train=X_train,
            y_train=y_train,
            top_k=config.TOP_K_GENES,
            lasso_c=config.LASSO_C,
            elasticnet_c=config.ELASTICNET_C,
            elasticnet_l1_ratio=config.ELASTICNET_L1_RATIO,
            max_iter=config.LOGISTIC_MAX_ITER,
            tol=config.LOGISTIC_TOL,
            coefficient_zero_tol=config.COEFFICIENT_ZERO_TOL,
            random_state=config.RANDOM_STATE,
            output_dir=method_dir / "feature_selection",
        )

        if len(genes) != min(config.TOP_K_GENES, X_train.shape[1]):
            raise RuntimeError(
                f"{method}: unexpected number of selected genes: {len(genes)}"
            )

        feature_summary_row = {
            "feature_method": method,
            "input_genes": feature_runtime["number_of_input_genes"],
            "total_nonzero_genes": feature_runtime[
                "total_number_of_nonzero_genes"
            ],
            "total_zero_genes": feature_runtime[
                "total_number_of_zero_genes"
            ],
            "nonzero_gene_fraction": feature_runtime[
                "nonzero_gene_fraction"
            ],
            "selected_genes": feature_runtime[
                "actual_selected_gene_count"
            ],
            "selected_nonzero_genes": feature_runtime[
                "selected_nonzero_genes"
            ],
            "selected_zero_genes": feature_runtime[
                "selected_zero_genes"
            ],
            "feature_selection_seconds": feature_runtime[
                "feature_selection_total_seconds"
            ],
            "convergence_warning_raised": feature_runtime[
                "convergence_warning_raised"
            ],
            "maximum_n_iter_used": feature_runtime[
                "maximum_n_iter_used"
            ],
        }

        feature_summary_rows.append(feature_summary_row)

        pd.DataFrame(feature_summary_rows).to_csv(
            config.OUTPUT_DIR / "feature_selection_summary_partial.csv",
            index=False,
        )

        X_train_selected = X_train.loc[:, genes].copy()
        X_test_selected = X_test.loc[:, genes].copy()

        selected_matrix_paths = {}

        if config.SAVE_SELECTED_MATRICES:
            selected_matrix_paths = save_selected_matrices(
                X_train,
                X_test,
                y_train_text,
                y_test_text,
                genes,
                method_dir / "selected_matrices",
                f"{method}_top_{len(genes)}",
            )

        method_metadata = {
            "method": method,
            "selected_gene_count": len(genes),
            "total_nonzero_genes": feature_runtime[
                "total_number_of_nonzero_genes"
            ],
            "total_zero_genes": feature_runtime[
                "total_number_of_zero_genes"
            ],
            "selected_nonzero_genes": feature_runtime[
                "selected_nonzero_genes"
            ],
            "selected_zero_genes": feature_runtime[
                "selected_zero_genes"
            ],
            "feature_selection_total_seconds": feature_runtime[
                "feature_selection_total_seconds"
            ],
            "selected_matrix_paths": selected_matrix_paths,
            "ranking_note": (
                "Genes with at least one nonzero class coefficient are ranked "
                "first by mean absolute multinomial coefficient, then by "
                "maximum absolute coefficient. Training-only ANOVA F-score "
                "is used only as a tie-breaker."
            ),
        }

        for classifier in args.classifiers:
            classifier_dir = method_dir / classifier

            best_classifier, classifier_bo_seconds = optimize_classifier(
                name=classifier,
                X_train=X_train_selected,
                y_train=y_train,
                cv_folds=config.CV_FOLDS,
                scoring=config.SCORING,
                init_points=config.CLF_BO_INIT_POINTS,
                n_iter=config.CLF_BO_ITERATIONS,
                n_jobs=config.N_JOBS,
                random_state=config.RANDOM_STATE,
                output_dir=classifier_dir,
            )

            metrics = fit_evaluate(
                name=classifier,
                best=best_classifier,
                X_train=X_train_selected,
                y_train=y_train,
                X_test=X_test_selected,
                y_test=y_test,
                class_names=encoder.classes_.tolist(),
                n_jobs=config.N_JOBS,
                bootstrap_repetitions=config.BOOTSTRAP_REPETITIONS,
                confidence_level=config.CONFIDENCE_LEVEL,
                random_state=config.RANDOM_STATE,
                output_dir=classifier_dir,
            )

            result_rows.append(
                {
                    "feature_method": method,
                    "classifier": classifier,
                    "input_genes": feature_runtime[
                        "number_of_input_genes"
                    ],
                    "total_nonzero_genes": feature_runtime[
                        "total_number_of_nonzero_genes"
                    ],
                    "total_zero_genes": feature_runtime[
                        "total_number_of_zero_genes"
                    ],
                    "selected_genes": len(genes),
                    "selected_nonzero_genes": feature_runtime[
                        "selected_nonzero_genes"
                    ],
                    "selected_zero_genes": feature_runtime[
                        "selected_zero_genes"
                    ],
                    "feature_selection_seconds": feature_runtime[
                        "feature_selection_total_seconds"
                    ],
                    "classifier_bo_seconds": classifier_bo_seconds,
                    "classifier_fit_seconds": metrics[
                        "model_fit_seconds"
                    ],
                    "prediction_seconds": metrics[
                        "prediction_seconds"
                    ],
                    "accuracy": metrics["accuracy"],
                    "accuracy_ci_lower": metrics[
                        "accuracy_ci_lower"
                    ],
                    "accuracy_ci_upper": metrics[
                        "accuracy_ci_upper"
                    ],
                    "weighted_f1": metrics["weighted_f1"],
                    "weighted_f1_ci_lower": metrics[
                        "weighted_f1_ci_lower"
                    ],
                    "weighted_f1_ci_upper": metrics[
                        "weighted_f1_ci_upper"
                    ],
                    "best_classifier_cv_score": best_classifier[
                        "best_cv_score"
                    ],
                }
            )

            pd.DataFrame(result_rows).to_csv(
                config.OUTPUT_DIR / "benchmark_summary_partial.csv",
                index=False,
            )

        method_metadata["complete_method_wall_seconds"] = float(
            time.perf_counter() - method_start
        )

        save_json(
            method_metadata,
            method_dir / "method_metadata.json",
        )

    feature_summary = pd.DataFrame(feature_summary_rows)
    benchmark_summary = pd.DataFrame(result_rows)

    feature_summary.to_csv(
        config.OUTPUT_DIR / "feature_selection_summary.csv",
        index=False,
    )

    benchmark_summary.to_csv(
        config.OUTPUT_DIR / "benchmark_summary.csv",
        index=False,
    )

    print("\nFINAL FEATURE-SELECTION SUMMARY", flush=True)
    print(feature_summary.to_string(index=False), flush=True)

    print("\nFINAL BENCHMARK SUMMARY", flush=True)
    print(benchmark_summary.to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
