from pathlib import Path

INPUT_FILE = Path("Cancer_Combine.filtered.csv")
CLASS_COLUMN = "Class"
OUTPUT_DIR = Path("benchmark_results")

RANDOM_STATE = 123
TEST_SIZE = 0.30
TOP_K_GENES = 14356

FEATURE_METHODS = ("lasso", "elasticnet")
CLASSIFIERS = ("rf", "xgb")

# Parallelism for RF and XGBoost.
N_JOBS = 16

# Cross-validation is used only for RF/XGBoost hyperparameter optimization.
CV_FOLDS = 3
SCORING = "f1_weighted"

# Bayesian optimization for downstream classifiers only.
CLF_BO_INIT_POINTS = 5
CLF_BO_ITERATIONS = 10

# Fixed feature-selection parameters.
LASSO_C = 1.0
ELASTICNET_C = 1.0
ELASTICNET_L1_RATIO = 0.5
LOGISTIC_MAX_ITER = 3000
LOGISTIC_TOL = 1e-3
COEFFICIENT_ZERO_TOL = 1e-12

BOOTSTRAP_REPETITIONS = 2000
CONFIDENCE_LEVEL = 0.95
SAVE_SELECTED_MATRICES = True
