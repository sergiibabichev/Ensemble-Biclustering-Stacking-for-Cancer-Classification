# Fixed LASSO / Elastic Net feature selection with optimized RF and XGBoost

## Workflow

1. The complete dataset is split once into stratified training and test subsets.
2. Standardization is fitted on the training subset only.
3. LASSO and Elastic Net are fitted once using fixed parameters.
4. Genes are ranked using multinomial logistic-regression coefficients.
5. The requested top-k genes are selected.
6. Random Forest and XGBoost hyperparameters are optimized using cross-validation on the training subset.
7. The held-out test subset is used only for final evaluation.

## Fixed feature-selection parameters

* LASSO: `C = 1.0`, `l1\_ratio = 1.0`
* Elastic Net: `C = 1.0`, `l1\_ratio = 0.5`
* Solver: `saga`
* Maximum iterations: `3000`
* Tolerance: `1e-3`

These values can be changed in `config.py`.

## Nonzero-gene reporting

A gene is considered nonzero if at least one class-specific logistic-regression coefficient satisfies:

`abs(coefficient) > COEFFICIENT\_ZERO\_TOL`

The default tolerance is `1e-12`.

For each feature-selection method, the program reports:

* total number of input genes;
* total number of nonzero genes;
* total number of zero genes;
* fraction of nonzero genes;
* number of selected genes;
* number of selected nonzero genes;
* number of selected zero-coefficient genes;
* convergence status and number of iterations.

The information is printed to the console and saved to:

* `benchmark\_results/feature\_selection\_summary.csv`
* `benchmark\_results/<method>/feature\_selection/<method>\_nonzero\_gene\_summary.json`
* `benchmark\_results/<method>/feature\_selection/<method>\_feature\_runtime.json`
* `benchmark\_results/<method>/<classifier>/...`
* `benchmark\_results/benchmark\_summary.csv`

The complete gene ranking contains the columns:

* `mean\_abs\_coefficient`
* `max\_abs\_coefficient`
* `nonzero\_class\_count`
* `is\_nonzero\_gene`
* `selected\_top\_k`

## Installation

```bash
pip install -r requirements.txt
```

## Dataset

Place `Cancer\_Combine.filtered.csv` in the same directory as the scripts.

The class column must be named `Class`, unless `CLASS\_COLUMN` is changed in `config.py`.

## Running

Run all feature-selection methods and classifiers:

```bash
python run\_benchmark.py
```

Only LASSO:

```bash
python run\_benchmark.py --methods lasso
```

Only Elastic Net:

```bash
python run\_benchmark.py --methods elasticnet
```

Only Random Forest after both feature-selection methods:

```bash
python run\_benchmark.py --classifiers rf
```

Only XGBoost after both feature-selection methods:

```bash
python run\_benchmark.py --classifiers xgb
```

Example: LASSO plus Random Forest only:

```bash
python run\_benchmark.py --methods lasso --classifiers rf
```

## 

